class Employee:
    def get_fired(self):
        return f"fired..."




#Employee with a single method get_fired() that returns: &quot;fired...&quot;